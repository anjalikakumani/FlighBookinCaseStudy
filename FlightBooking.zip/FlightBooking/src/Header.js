import React from "react";

class Header extends React.Component {
  render() {
    return (
      <header className="header headerone">
        <h1>Flight Booking System</h1>
      </header>
    );
  }
}

export default Header;
