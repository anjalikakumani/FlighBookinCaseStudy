import React from "react";

class Footer extends React.Component {
  render() {
    return (
      <footer>
        <h1>Terms and conditions</h1>
      </footer>
    );
  }
}

export default Footer;
