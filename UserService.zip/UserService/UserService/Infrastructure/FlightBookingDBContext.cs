﻿
using Microsoft.EntityFrameworkCore;
using UserService.Models;

namespace UserService.Infrastructure
{
    public class FlightBookingDBContext:DbContext
    {
        public FlightBookingDBContext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<BookingDetails> BookingDetails { get; set; }

        public DbSet<TravellerDetails> TravellerDetails { get; set; }

    }
}
