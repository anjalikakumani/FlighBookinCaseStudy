﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Swashbuckle.AspNetCore.Swagger;
using UserService.Filters;
using UserService.Infrastructure;
using UserService.Models;
using UserService.Repositories;

namespace UserService
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddDefaultPolicy(policy =>
                {
                    policy.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader();
                });
            });

        
            services.AddDbContext<FlightBookingDBContext>(options =>
            {
                options.UseSqlServer(Configuration.GetValue<string>("ConnectionString"));
            });

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new Info
                {
                    Title = "User Service API",
                    Version = "v1",
                    Contact = new Contact
                    {
                        Name = "Ajay Vishnu",
                        Email = "ajayvishnud@hexaware.com"
                    },
                    Description = "User Service API for Flight Booking",
                    TermsOfService = string.Empty
                });
            });

            services.AddScoped<IRepository<BookingDetails>, Repository<BookingDetails>>();
            services.AddScoped<IRepository<TravellerDetails>, Repository<TravellerDetails>>();

            services.AddDistributedRedisCache(options =>
            {
                options.InstanceName = "MyRedis";
                options.Configuration = "127.0.0.1:6379";
            });

            services.AddMvc(options =>
            {
                options.Filters.Add(typeof(ApiExceptionFilter));
            })
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler(options =>
                {
                    options.Run(async (context) =>
                    {
                        context.Response.StatusCode = 500;
                        var msg = "Some error occured in the server";
                        await context.Response.WriteAsync(msg);
                    });
                });
            }

            app.UseStaticFiles();
            app.UseAuthentication();
            InitializeDB(app);
            app.UseCors();
            app.UseSwagger();
            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/swagger/v1/swagger.json", "HexaBlog API");
                options.RoutePrefix = string.Empty;
            });

            app.UseMvc();
        }

        private void InitializeDB(IApplicationBuilder app)
        {
            using (var serviceScope = app.ApplicationServices.GetService<IServiceScopeFactory>().CreateScope())
            {
                serviceScope.ServiceProvider.GetRequiredService<FlightBookingDBContext>().Database.Migrate();
            }
        }
    }
}
