﻿namespace UserService.Models
{
    public class EntityBase
    {
        public virtual int Id { get; set; }
    }
}