﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using UserService.Models;
using UserService.Repositories;

namespace UserService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TravellerController : ControllerBase
    {
        private IRepository<BookingDetails> bookingRepository;
        private readonly IDistributedCache distributedCache;

        public TravellerController(IRepository<BookingDetails> bookingRepo, IDistributedCache distributedCache)
        {
            this.bookingRepository = bookingRepo;
            this.distributedCache = distributedCache;
        }

        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [HttpPost("", Name = "StoreTravellerDetails")]
        public async Task<ActionResult<BookingDetails>> StoreTravellerDetails(TravellerDetails travellerDetails)
        {
            if (travellerDetails == null)
            {
                return BadRequest();
            }           
            
            var bookingDetails = await bookingRepository.AddAsync(new BookingDetails { Status = "Pending" });

            travellerDetails.BookingId = bookingDetails.Id;
            this.distributedCache.SetString(bookingDetails.Id.ToString(), Newtonsoft.Json.JsonConvert.SerializeObject(travellerDetails));

            return bookingDetails;

        }
    }
}