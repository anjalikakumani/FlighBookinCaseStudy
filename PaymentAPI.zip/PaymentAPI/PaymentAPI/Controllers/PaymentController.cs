﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;
using PaymentAPI.Filters;
using PaymentAPI.Models;
using PaymentAPI.Repositories;

namespace PaymentAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private IRepository<PaymentDetails> paymentRepository;
        private IRepository<BookingDetails> bookingRepository;
        private IRepository<TravellerDetails> travellerRepository;
        private IDistributedCache distributedCache;

        public PaymentController(IRepository<PaymentDetails> paymentRepo, IRepository<BookingDetails> bookingRepo, IDistributedCache distributedCache, IRepository<TravellerDetails> travellerRepository)
        {
            this.paymentRepository = paymentRepo;
            this.bookingRepository = bookingRepo;
            this.distributedCache = distributedCache;
            this.travellerRepository = travellerRepository;

        }

        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [HttpPost("", Name = "Booking")]
        public async Task<ActionResult<PaymentDetails>> Booking([FromBody]PaymentDetails paymentDetails)
        {
            if (paymentDetails == null)
            {
                return BadRequest();
            }
            var paymentResult = await this.paymentRepository.AddAsync(paymentDetails);

            if (paymentResult != null)
            {
                var redisresult = JsonConvert.DeserializeObject<TravellerDetails>(await this.distributedCache.GetStringAsync(paymentDetails.BookingId.ToString()));
                await travellerRepository.AddAsync(redisresult);

                BookingDetails bookingDetails = new BookingDetails
                {
                    Id = paymentDetails.BookingId,
                    Status ="Booked"
                 };

                await bookingRepository.UpdateAsync(paymentDetails.BookingId,bookingDetails);

            }
            return paymentResult;

        }

        //PUT /api/blogs/{id}
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesResponseType(200)]
        [HttpPut("{id:int?}", Name = "CancelBooking")]
        public async Task<ActionResult<PaymentDetails>> CancelBooking(int id)
        {
            var paymentDetails = this.paymentRepository.GetAll().Where(pay => pay.BookingId == id).SingleOrDefault();
            paymentDetails.Mode = "Refunded";
            var paymentRecord = await this.paymentRepository.UpdateAsync(id, paymentDetails);

            if (paymentRecord != null)
            {
                var bookingRecord = await this.bookingRepository.GetByIdAsync(id);
                bookingRecord.Status = "Cancelled";
                await bookingRepository.UpdateAsync(id, bookingRecord);
            }
            return paymentRecord;
        }
    }
}