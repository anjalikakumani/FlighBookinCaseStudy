﻿using Microsoft.EntityFrameworkCore;
using PaymentAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PaymentAPI.Context
{
    public class FlightBookingDBContext : DbContext
    {
        public FlightBookingDBContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<PaymentDetails> PaymentDetails { get; set; }

        public DbSet<BookingDetails> BookingDetails { get; set; }

        public DbSet<TravellerDetails> TravellerDetails { get; set; }

      
    }
}
