﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace PaymentAPI.Models
{   
        public class PaymentDetails : EntityBase
        {
            [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
            [Key]
            public override int Id { get; set; }

            [Required]
            public string PaymentType { get; set; }

            [Required]
            public int BookingId { get; set; }

            [Required, DataType(DataType.DateTime)]
            public DateTime Date { get; set; }

            [Required]
            public decimal BaseFare { get; set; }

            [Required]
            public decimal InsuranceAmount { get; set; }

            [Required]
            public decimal Tax { get; set; }

            [Required]
            public decimal ServiceCharge { get; set; }

            [Required]
            public decimal TotalAmount { get; set; }

            [Required]
            [ForeignKey("BookingId")]
            public string Mode { get; set; }
        }
    }

