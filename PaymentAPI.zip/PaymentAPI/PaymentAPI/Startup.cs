﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using PaymentAPI.Context;
using PaymentAPI.Filters;
using PaymentAPI.Models;
using PaymentAPI.Repositories;
using Swashbuckle.AspNetCore.Swagger;

namespace PaymentAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddDefaultPolicy(policy =>
                {
                    policy.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader();
                });
            });
            services.AddDistributedRedisCache(options =>
            {
                options.InstanceName = "MyRedis";
                options.Configuration = "127.0.0.1:6379";
            });

            services.AddDbContext<FlightBookingDBContext>(options =>
            {
                options.UseSqlServer(Configuration.GetValue<string>("ConnectionString"));
            });

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new Info
                {
                    Title = "User Service API",
                    Version = "v1",
                    Contact = new Contact
                    {
                        Name = "Anjali",
                        Email = "Anjali@hexaware.com"
                    },
                    Description = "Payment Service API for Flight Booking",
                    TermsOfService = string.Empty
                });
            });

            services.AddScoped<IRepository<BookingDetails>, Repository<BookingDetails>>();
            services.AddScoped<IRepository<PaymentDetails>, Repository<PaymentDetails>>();
            services.AddScoped<IRepository<TravellerDetails>, Repository<TravellerDetails>>();





            services.AddMvc(options =>
            {
                options.Filters.Add(typeof(ApiExceptionFilter));
            })
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler(options =>
                {
                    options.Run(async (context) =>
                    {
                        context.Response.StatusCode = 500;
                        var msg = "Some error occured in the server";
                        await context.Response.WriteAsync(msg);
                    });
                });
            }

            app.UseStaticFiles();
            app.UseAuthentication();
            //InitializeDB(app);
            app.UseCors();
            app.UseSwagger();
            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/swagger/v1/swagger.json", "HexaBlog API");
                options.RoutePrefix = string.Empty;
            });

            app.UseMvc();
        }
        private void InitializeDB(IApplicationBuilder app)
        {
            using (var serviceScope = app.ApplicationServices.GetService<IServiceScopeFactory>().CreateScope())
            {
                serviceScope.ServiceProvider.GetRequiredService<FlightBookingDBContext>().Database.Migrate();
            }
        }
    }
}
