﻿using Microsoft.EntityFrameworkCore;
using SearchFlightsApp.Context;
using SearchFlightsApp.Models;
using System.Collections.Generic;
using System.Linq;



namespace SearchFlightsApp.Repositories
{
    public class Repository<T>: IRepository<T> where T : SearchFlightsApp.Models.FlightData
    {
        private readonly FlightDataContext db;
        private readonly DbSet<T> entities;

        public Repository(FlightDataContext dbContext)
        {
            this.db = dbContext;
            this.entities = dbContext.Set<T>();
        }

        public  IEnumerable<T> GetFlightDetails(FlightData flightdata)
        {
            var flightList = this.entities.
                                 Where(Data => (Data.Source == flightdata.Source
                                             && Data.Destination == flightdata.Destination
                                             && Data.Departure.ToShortDateString() == flightdata.Departure.ToShortDateString()
                                             && Data.Return.ToShortDateString() == flightdata.Return.ToShortDateString()
                                             && Data.FleetType == flightdata.FleetType) ||
                                             (Data.Source == flightdata.Source
                                             && Data.Destination == flightdata.Destination
                                             && Data.Departure.ToShortDateString() == flightdata.Departure.ToShortDateString()
                                            && Data.FleetType == flightdata.FleetType))
                                 .ToList();
          //  var flightList = this.entities.ToList();
            return flightList;           
        }

        public long GetBaseFare(int flightId)
        {
            var baseFare = this.entities.
                                 Where(Data => Data.FlightId == flightId).SingleOrDefault().Price;
            return baseFare;
        }
    }
}
