﻿using SearchFlightsApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchFlightsApp.Repositories
{
    public interface IRepository<T>
    {
        IEnumerable<T> GetFlightDetails(FlightData flightData);

        long GetBaseFare(int flightId);

    }

}