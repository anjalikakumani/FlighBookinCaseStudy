﻿using Microsoft.EntityFrameworkCore;
using SearchFlightsApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchFlightsApp.Context
{
    public class FlightDataContext:DbContext
    {
        public FlightDataContext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<FlightData> Flightdata { get; set; }
    }
}
