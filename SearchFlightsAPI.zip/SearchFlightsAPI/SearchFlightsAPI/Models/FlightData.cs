﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace SearchFlightsApp.Models
{
    public class FlightData : EntityBase
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public override int FlightId { get; set; }
  
        public string AirlinesName { get; set; }

        [Required]
        public string Source { get; set; }

        [Required]
        public string Destination { get; set; }

        [Required, DataType(DataType.DateTime)]
        public DateTime Departure { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime Arrival { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime Return { get; set; }
      
        public Decimal Duration { get; set; }
   
        public long Price { get; set; }
     
        public string FleetType { get; set; }
    }
}
