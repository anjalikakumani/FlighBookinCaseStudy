﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchFlightsApp.Models
{
        public abstract class EntityBase
        {
            public virtual int FlightId { get; set; }
        }
   
}
