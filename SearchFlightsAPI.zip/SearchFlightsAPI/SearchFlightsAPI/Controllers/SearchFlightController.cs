﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SearchFlightsApp.Models;
using SearchFlightsApp.Repositories;

namespace SearchFlightsApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class SearchFlightController : ControllerBase
    {
        private IRepository<FlightData> repository;

        public SearchFlightController(IRepository<FlightData> repo)
        {
            this.repository = repo;
        }
        //Post /api/SearchFlight/{flightData}    
        [HttpPost]
        public IEnumerable<FlightData> GetFlightDetails([FromBody]FlightData flightData)
        {
            var item =  this.repository.GetFlightDetails(flightData);          
                return item;
        }

        [HttpGet]
        public long GetBaseFare(int flightId)
        {
            var fare = this.repository.GetBaseFare(flightId);
            return fare;
        }
    }
}